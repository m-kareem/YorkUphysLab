# York University physics lab

This is package that includes the required drivers to controle some of the hardwares in physics labs at YorkU.
Developed by:

Mohammad Kareem, Ph.D.
Laboratory Technologist
Department of Physics & Astronomy
Faculty of Science | YORK UNIVERSITY